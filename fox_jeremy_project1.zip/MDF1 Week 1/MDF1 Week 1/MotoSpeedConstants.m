//
//  MotoSpeedConstants.m
//  MDF1 Week 1
//
//  Created by Jeremy Fox on 9/25/12.
//  Copyright (c) 2012 Jeremy Fox. All rights reserved.
//
//  **********************************************************
//  Please Not: All photos and bike info were borrowed from
//  http://www.sub5zero.com/top-20-fastest-street-bikes-world/
//  **********************************************************

#import "MotoSpeedConstants.h"

@implementation MotoSpeedConstants

@end
